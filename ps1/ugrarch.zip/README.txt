1-Solicita permiso para conectarte a la red local desde el laboratorio "ugrlab".
2-Cambia la linea: '$localPath = "C:\Users\Usuario\Desktop"' con tu usuario
3-Ejecuta el archivo "ugrarch.ps1" desde una consola de PowerShell.
4-Espera a que se complete la ejecución del archivo.
5-Importa el archivo "ugrlab.ova" en VirtualBox.
6-¡Listo!

1-Request permission to connect to the local network from the "ugrlab" lab.
2-Change the line '$localPath = "C:\Users\Usuario\Desktop"' with your user
3-Execute the "ugrarch.ps1" file from a PowerShell console.
4-Wait for the execution of the file to complete.
5-Import the "ugrlab.ova" file into VirtualBox.
6-Done!